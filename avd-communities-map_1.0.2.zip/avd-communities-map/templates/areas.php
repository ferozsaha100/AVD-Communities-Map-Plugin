<?php
/**
 * Template: Areas Embed
 * PHP-driven version of avdc-areas-embed.html
 *
 * STRUCTURE:
 *   <section.avdc-areas>                  — CSS grid: 1fr 1fr
 *     <div.avdc-areas__left>              — white left panel
 *     <div.avdc-areas__right>             — sticky map panel (position:sticky + position:relative)
 *       <div#avdc-map>                    — Google Maps fills 100%
 *       <div.avdc-areas__map-top>         — city overlay (position:absolute)
 *       <div.avdc-areas__pin>             — pulse pin (position:absolute)
 *       <div.avdc-areas__map-bot>         — hint + CTA (position:absolute)
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<section class="avdc-areas">

  <!-- ══ LEFT: Photo Card Grid ══════════════════════ -->
  <div class="avdc-areas__left">

    <p class="avdc-areas__eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
    <h2 class="avdc-areas__title"><?php echo wp_kses( $title, array( 'em' => array() ) ); ?></h2>
    <p class="avdc-areas__subtitle"><?php echo esc_html( $subtitle ); ?></p>

    <div class="avdc-areas__grid">

      <?php foreach ( $grouped as $group_label => $group_areas ) : ?>

        <div class="avdc-areas__divider">
          <span><?php echo esc_html( $group_label ); ?></span>
        </div>

        <?php foreach ( $group_areas as $area ) :
          $is_first = ( $area->id === $first_area->id );
          $bg_style = ! empty( $area->image_url )
            ? 'background-image:url(' . esc_url( $area->image_url ) . ');'
            : 'background:linear-gradient(135deg,#1a1a40,#302EB7);';
        ?>

        <div class="avdc-areas__card<?php echo $is_first ? ' avdc-active' : ''; ?>"
             data-city="<?php echo esc_attr( $area->area_name ); ?>"
             data-state="<?php echo esc_attr( $area->state ); ?>"
             data-lat="<?php echo esc_attr( $area->lat ); ?>"
             data-lng="<?php echo esc_attr( $area->lng ); ?>"
             data-zoom="<?php echo esc_attr( $area->zoom ); ?>"
             data-link="<?php echo esc_url( $area->custom_link ); ?>">
          <div class="avdc-areas__bar"></div>
          <div class="avdc-areas__bg" style="<?php echo $bg_style; ?>"></div>
          <div class="avdc-areas__label">
            <span class="avdc-areas__name"><?php echo esc_html( $area->area_name ); ?></span>
            <span class="avdc-areas__arrow">→</span>
          </div>
        </div>

        <?php endforeach; ?>
      <?php endforeach; ?>

    </div><!-- /avdc-areas__grid -->
  </div><!-- /avdc-areas__left -->


  <!-- ══ RIGHT: Sticky Map ══════════════════════════ -->
  <!--
    IMPORTANT: position:sticky sets this as a containing block,
    but we also add an inner wrapper with position:relative so the
    absolute-positioned overlays (map-top, map-bot, pin) anchor here.
  -->
  <div class="avdc-areas__right">

    <!-- Inner wrapper — provides the position:relative containing block -->
    <div class="avdc-areas__map-inner">

      <!-- Google Maps renders here -->
      <div id="avdc-map" style="--map-bg:<?php echo esc_attr( $map_bg ); ?>; background:<?php echo esc_attr( $map_bg ); ?>;">
        <!-- Placeholder until API loads -->
        <div class="avdc-areas__map-placeholder" id="avdcPlaceholder">
          <div class="avdc-ph-icon">🗺️</div>
          <div class="avdc-ph-city" id="avdcPhCity">
            <?php echo esc_html( $first_area->area_name . ', ' . $first_area->state ); ?>
          </div>
          <?php if ( empty( $api_key ) ) : ?>
            <p>Google Maps loads here.<br>Add your API key in Settings to activate.</p>
            <code>Appearance → AVD Map Guide → Settings</code>
          <?php else : ?>
            <p>Loading map…</p>
          <?php endif; ?>
        </div>
      </div>

      <!-- City name overlay — top -->
      <div class="avdc-areas__map-top">
        <div class="avdc-areas__map-city avdc-vis" id="avdcMapCity">
          <?php echo esc_html( $first_area->area_name . ', ' . $first_area->state ); ?>
        </div>
      </div>

      <!-- Pulse pin — decorative center dot -->
      <div class="avdc-areas__pin" id="avdcPin">
        <div class="avdc-areas__pin-dot"></div>
      </div>

      <!-- Bottom bar — hover hint + CTA -->
      <div class="avdc-areas__map-bot">
        <span class="avdc-areas__map-hint">Hover any area to explore on map</span>
        <?php if ( $cta_url && $cta_text ) : ?>
          <a href="<?php echo esc_url( $cta_url ); ?>" class="avdc-areas__map-cta">
            <?php echo esc_html( $cta_text ); ?>
          </a>
        <?php endif; ?>
      </div>

    </div><!-- /avdc-areas__map-inner -->
  </div><!-- /avdc-areas__right -->

</section>
